"use client";

import FormInput from "@/components/ui/FormInput";
import Button from "@/components/ui/Button";
import { useState } from "react";
import { useExerciseStore } from '../hooks/useExerciseStore';
import { BookOpen, Trash2, Plus, AlertCircle, Copy, GripVertical } from "lucide-react";

type VocabWord = { word: string; translation: string };
type Item = { words: VocabWord[] };

type Props = {
  id_class: string;
  type: "overview_session";
  order_index: number;
};

export default function OverviewExerciseForm({ order_index }: Props) {
  const { data, updateExercise } = useExerciseStore();
  const exercise = data[order_index] || {
    name: "",
    description: "",
    content: { items: [{ words: [] }] },
  };

  const items: Item[] = exercise.content?.items || [];
  const [wordInputs, setWordInputs] = useState<Record<number, { word: string; translation: string }>>({});
  const [draggedItemIndex, setDraggedItemIndex] = useState<number | null>(null);
  const [dragOverItemIndex, setDragOverItemIndex] = useState<number | null>(null);
  const [draggableIndex, setDraggableIndex] = useState<number | null>(null);

  const getWordInput = (itemIndex: number) =>
    wordInputs[itemIndex] || { word: "", translation: "" };

  const setWordInput = (itemIndex: number, field: "word" | "translation", value: string) => {
    setWordInputs((prev) => ({
      ...prev,
      [itemIndex]: { ...getWordInput(itemIndex), [field]: value },
    }));
  };

  const clearWordInput = (itemIndex: number) => {
    setWordInputs((prev) => {
      const next = { ...prev };
      delete next[itemIndex];
      return next;
    });
  };

  const reorderItems = (fromIndex: number, toIndex: number) => {
    const newItems = [...items];
    const [movedItem] = newItems.splice(fromIndex, 1);
    newItems.splice(toIndex, 0, movedItem);
    updateContent("items", newItems);
    setWordInputs({});
  };

  const updateField = (field: string, value: any) => {
    updateExercise(order_index, { ...exercise, [field]: value });
  };

  const updateContent = (field: string, value: any) => {
    updateExercise(order_index, {
      ...exercise,
      content: { ...exercise.content, [field]: value },
    });
  };

  const addItem = () => updateContent("items", [...items, { words: [] }]);

  const copyLastSection = () => {
    if (items.length === 0) return;
    const lastItem = items[items.length - 1];
    const duplicated: Item = {
      words: lastItem.words.map((w) => ({ ...w })),
    };
    updateContent("items", [...items, duplicated]);
  };

  const removeItem = (index: number) => {
    updateContent(
      "items",
      items.filter((_, i) => i !== index),
    );
    setWordInputs({});
  };

  const addWordToItem = (itemIndex: number) => {
    const { word, translation } = getWordInput(itemIndex);
    const w = word.trim();
    const t = translation.trim();
    if (!w || !t) return;

    const updated = items.map((item, i) =>
      i === itemIndex
        ? { ...item, words: [...item.words, { word: w, translation: t }] }
        : item,
    );
    updateContent("items", updated);
    clearWordInput(itemIndex);
  };

  const removeWordFromItem = (itemIndex: number, wordIndex: number) => {
    const updated = items.map((item, i) =>
      i === itemIndex
        ? { ...item, words: item.words.filter((_, j) => j !== wordIndex) }
        : item,
    );
    updateContent("items", updated);
  };

  return (
    <div className="w-full space-y-4">
      <FormInput
        label="Title"
        placeholder="e.g. Animals Vocabulary"
        value={exercise.name}
        onChangeText={(text) => updateField("name", text)}
        onCopy={() => navigator.clipboard.writeText(exercise.name)}
      />
      <FormInput
        label="Description"
        placeholder="e.g. Learn the names of common animals"
        value={exercise.description}
        onChangeText={(text) => updateField("description", text)}
        multiline
        onCopy={() => navigator.clipboard.writeText(exercise.description)}
      />

      <div className="mt-4">
        <label className="text-sm font-medium text-slate-650 mb-2 block">Vocabulary Sections</label>

        {items.length === 0 && (
          <div className="p-6 text-center flex flex-col items-center justify-center text-slate-500 bg-slate-100/40 border border-dashed border-slate-200 rounded-xl mb-4">
            <BookOpen size={24} className="text-slate-500 mx-auto mb-2" />
            No sections added yet
          </div>
        )}

        {items.map((item, itemIndex) => {
          const isItemInvalid = !item.words || item.words.length === 0;
          return (
            <div
              key={itemIndex}
              draggable={draggableIndex === itemIndex}
              onDragStart={(e) => {
                e.stopPropagation();
                setDraggedItemIndex(itemIndex);
                e.dataTransfer.effectAllowed = "move";
                e.dataTransfer.setData("text/plain", itemIndex.toString());
              }}
              onDragOver={(e) => {
                e.preventDefault();
                e.stopPropagation();
                if (dragOverItemIndex !== itemIndex) {
                  setDragOverItemIndex(itemIndex);
                }
              }}
              onDragLeave={(e) => {
                e.stopPropagation();
                setDragOverItemIndex(null);
              }}
              onDrop={(e) => {
                e.preventDefault();
                e.stopPropagation();
                const fromIndex = draggedItemIndex;
                if (fromIndex !== null && fromIndex !== itemIndex) {
                  reorderItems(fromIndex, itemIndex);
                }
                setDraggedItemIndex(null);
                setDragOverItemIndex(null);
                setDraggableIndex(null);
              }}
              onDragEnd={(e) => {
                e.stopPropagation();
                setDraggedItemIndex(null);
                setDragOverItemIndex(null);
                setDraggableIndex(null);
              }}
              className={`mt-4 p-5 bg-slate-50/70 rounded-xl border transition-all duration-200 ${
              isItemInvalid ? "border-amber-300 bg-amber-50/10" : "border-slate-200/80"
            } ${
              draggedItemIndex === itemIndex ? "opacity-35 scale-[0.98]" : ""
            } ${
              dragOverItemIndex === itemIndex && draggedItemIndex !== itemIndex
                ? "ring-2 ring-cyan-500 ring-offset-2 rounded-xl scale-[1.01]"
                : ""
            }`}>
            <div className="flex justify-between items-center mb-3">
              <div className="flex items-center gap-2">
                {items.length > 1 && (
                  <div
                    className="text-slate-400 hover:text-slate-655 cursor-grab active:cursor-grabbing p-1 rounded hover:bg-slate-200/50 transition-colors"
                    onMouseDown={() => setDraggableIndex(itemIndex)}
                    onMouseUp={() => setDraggableIndex(null)}
                    title="Arrastrar para reordenar"
                  >
                    <GripVertical size={18} />
                  </div>
                )}
                <BookOpen size={18} className="text-cyan-650" />
                <span className="font-semibold text-cyan-650 text-sm tracking-wide uppercase">Section {itemIndex + 1}</span>
              </div>
              <button
                className="text-slate-500 hover:text-rose-600 transition-colors p-1 rounded-lg hover:bg-rose-500/5"
                onClick={() => removeItem(itemIndex)}
              >
                <Trash2 size={18} />
              </button>
            </div>

            {item.words.map((word, wordIndex) => (
              <div key={wordIndex} className="flex items-center justify-between p-3 mb-2 bg-slate-50/50 border border-slate-200/50 rounded-lg">
                <div className="flex flex-col">
                  <span className="font-medium text-slate-700">{word.word}</span>
                  <span className="text-sm text-slate-500">{word.translation}</span>
                </div>
                <button
                  className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-500/5 rounded-lg transition-colors"
                  onClick={() => removeWordFromItem(itemIndex, wordIndex)}
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))}

            {item.words.length === 0 && (
              <p className="text-sm text-slate-500 text-center py-4">No words in this section</p>
            )}

            <div className="mt-4 p-4 bg-slate-50 rounded-xl border border-slate-200">
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1">
                  <FormInput
                    label="English Word"
                    placeholder="e.g. Dog"
                    value={getWordInput(itemIndex).word}
                    onChangeText={(text) => setWordInput(itemIndex, "word", text)}
                  />
                </div>
                <div className="flex-1">
                  <FormInput
                    label="Translation"
                    placeholder="e.g. Perro"
                    value={getWordInput(itemIndex).translation}
                    onChangeText={(text) => setWordInput(itemIndex, "translation", text)}
                  />
                </div>
              </div>
              <Button
                variant="outlined"
                onClick={() => addWordToItem(itemIndex)}
                disabled={!getWordInput(itemIndex).word.trim() || !getWordInput(itemIndex).translation.trim()}
                leftIcon={<Plus size={18} />}
                className="mt-4 w-full"
              >
                Add Word
              </Button>
            </div>

            {isItemInvalid && (
              <div className="mt-3 flex items-center gap-1.5 text-xs text-amber-600 font-semibold bg-amber-50/50 p-2 rounded-lg border border-amber-100">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>Se requiere agregar al menos una palabra con su respectiva traducción.</span>
              </div>
            )}
          </div>
        );
      })}

        <Button
          variant="outlined"
          onClick={addItem}
          leftIcon={<Plus size={18} />}
          className="w-full mt-4 border-dashed hover:border-cyan-500/30 text-cyan-650 hover:bg-cyan-500/5"
        >
          Add section
        </Button>

        <Button
          variant="outlined"
          onClick={copyLastSection}
          disabled={items.length === 0}
          leftIcon={<Copy size={18} />}
          className="w-full mt-2 border-dashed hover:border-emerald-500/30 text-emerald-650 hover:bg-emerald-500/5"
        >
          Copy lesson
        </Button>
      </div>
    </div>
  );
}
